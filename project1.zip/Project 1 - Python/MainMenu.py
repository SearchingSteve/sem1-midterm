# Description: Midterm Sprint - Project 1: Python
# SD-11 - Group 23
# Main Menu
# Author: Michelle Anderson and Stephen Crocker
# Date(s): Feb 28, 2024

# Define required libraries.
import datetime
from datetime import timedelta

# Define program constants.
global CUR_DATE
CUR_DATE = datetime.datetime.now()

# Counters for the program.
global Q1Ctr, Q2Ctr, Q3Ctr, Q4Ctr, Q5Ctr
Q1Ctr = 0
Q2Ctr = 0
Q3Ctr = 0
Q4Ctr = 0
Q5Ctr = 0


# Define program functions.

# Program 1 - NL Chocolate Company Travel Claim
def Q1():
    # Initialize global counter
    global Q1Ctr

    # A program to process travel claims for the NL Chocolate company
    # Date: February 20, 2024
    # Author: Michelle Anderson and Stephen Crocker


    # Constants
    DAILY_RATE = 85.00
    PER_KM_RATE = 0.17  # rate if employees uses rental car
    RENTAL_RATE = 65.00
    HST_RATE = 0.15
    BONUS_MILEAGE_RATE = 0.04
    EXEC_DAILY_BONUS = 45.00

    # Gather inputs


    while True:
        EmpNum = input("Enter the employee number (99999), enter -1 to exit: ")
        if EmpNum == "-1":
            break

        elif EmpNum == "":
            print("Data Entry Error - Employee number cannot be blank.")
            continue

        elif len(EmpNum) != 5:
            print("Data Entry Error - Employee number must be 5 digits.")
            continue


        while True:
            EmpFirstName = input("Enter the employee's first name: ")
            if EmpFirstName == "":
                print("Data Entry Error - Customer first name cannot be blank.")
            else:
                break

        while True:
            EmpLastName = input("Enter the employee's last name: ")
            if EmpLastName == "":
                print("Data Entry Error - Customer last name cannot be blank.")
            else:
                break

        TripLocation = input("Enter the employees trip location: ").title()

        while True:
            try:
                StartDate = input("Enter the employee's trip start date (YYYY-MM-DD): ")
                StartDate = datetime.datetime.strptime(StartDate, "%Y-%m-%d")
            except:
                print("Data Entry Error - start date is not in a valid format.")
            else:
                break

        while True:
            try:
                EndDate = input("Enter the employee's trip end date (YYYY-MM-DD): ")
                EndDate = datetime.datetime.strptime(EndDate, "%Y-%m-%d")

            except:
                print("Data Entry Error - end date is not in a valid format.")
            else:
                DateDifference = EndDate - StartDate
                NumDays = int(DateDifference.days)
                if EndDate < StartDate:
                    print("Data Entry Error - end date cannot be earlier than the start date.")
                elif DateDifference > timedelta(days=7):
                    print("The second date must be within 7 days after the first date.")
                else:
                    break

        while True:
            CarUsed = str(input("Enter whether the employee used their Own car or a Rental car (O / R): ")).upper()
            print(CarUsed)
            if (CarUsed == "O"):
                print("Car used is Own")

                while True:

                    KmsTravelled = int(input("Enter Kilometers Travelled: "))
                    if KmsTravelled > 2000:
                        print("Data entry error - cannot exceed 2000 km")
                    elif KmsTravelled < 0:
                        print("Data entry error - cannot be a negative number")
                    else:
                        break
                break
            elif (CarUsed == "R"):
                print("Car used is Rental")
                KmsTravelled = None
                break
            else:
                print("incorrect input")

        while True:
            ClaimType = input("Enter the status of the claim type as Standard or Executive (S / E): ").upper()
            if ClaimType == "":
                print("Data Entry Error - Claim type cannot be blank.")
            else:
                break

        # calculations

        TotalDiemCost = NumDays * DAILY_RATE

        if CarUsed == "O":
            MileageCost = PER_KM_RATE * KmsTravelled
        else:
            MileageCost = RENTAL_RATE * NumDays

        BonusAmt = 0
        if NumDays > 3:
            BonusAmt += 100

        if KmsTravelled == None:
            MileageBonus = 0
        elif KmsTravelled > 1000 and CarUsed == "O":
            MileageBonus = KmsTravelled * BONUS_MILEAGE_RATE
        else:
            MileageBonus = 0

        BonusAmt += MileageBonus

        if ClaimType == "E":
            BonusAmt = + EXEC_DAILY_BONUS

        if (StartDate.month == 12) and (15 >= StartDate.day <= 22):
            BonusAmt += 50.00

        ClaimAmt = TotalDiemCost + MileageCost + BonusAmt

        Taxes = ClaimAmt * HST_RATE

        TotalClaimAmt = ClaimAmt + Taxes

        # Display outputs

        print()
        print()
        print(f"                          NL Chocolate Company")
        print(f"                          Travel Claim Receipt")
        print()
        print(f"______________________________________________________________")
        print()

        print(f"Employee Number: {EmpNum:<5s}")
        print()
        EmpName = (EmpFirstName + " " + EmpLastName)
        EmpName = EmpName.title()
        print(f"Employee Name: {EmpName:<30s}")
        print()
        print(f"Trip Location: {TripLocation:<30s}")
        print()
        StartDateDsp = StartDate.strftime("%d-%b-%y")
        print(f"Start Date: {StartDateDsp:<10s}")
        print()
        EndDateDsp = EndDate.strftime("%d-%b-%y")
        print(f"End Date: {EndDateDsp:<10s}")
        print()
        print(f"Number of days travelled: {NumDays:<2d}")
        print()
        print(f"Type of vehicle used, Own or Rental: {CarUsed:<8s}")
        print()
        if KmsTravelled != None:
            print(f" Kilometers Tavelled: {KmsTravelled:<5d}")

        if MileageBonus != None:
            print(f" Mileage: {MileageBonus}")

        print()

        print(f"Claim Type: {ClaimType:<9s}")
        print()
        BonusAmtDsp = "${:.2f}".format(BonusAmt)
        print(f"Bonus Amount: {BonusAmtDsp:<9s} ")
        print()
        print(f"Number of Days Rented: {NumDays:<2d}")
        print()
        TotalDiemCostDsp = "${:.2f}".format(TotalDiemCost)
        print(f"Per Diem Amount: {TotalDiemCostDsp:<9s}")
        print()
        ClaimAmtDsp = "${:.2f}".format(ClaimAmt)
        print(f"Claim Amount: {ClaimAmtDsp:<9s}")
        print()
        TaxesDsp = "${:.2f}".format(Taxes)
        print(f"Taxes: {TaxesDsp:9s}")
        print()
        TotalClaimAmtDsp = "${:.2f}".format(TotalClaimAmt)
        print(f"Total Claim Amount: {TotalClaimAmtDsp:9s}")
        print()
        print("____________________________________________________________________")
        print()


        # Update global counter
        Q1Ctr += 1

        while True:
            Continue = input("Do you want to Process Another Sale (Y / N)?: ").upper()
            if Continue != "Y" and Continue != "N":
                print("Enter Y to Process Another Sale, or N to exit - Please re-enter.")
            elif Continue == "N":
                exit()





# Program 2 - The FizzBizz problem
# Author: Stephen Crocker
# Dated - Feb 19, 2024
def Q2():

    # Initialize global counter
    global Q2Ctr

    # Iterates 100 times and uses modulo to check if the currently iterated number is divided by 5, 8, 5 and 8, or neither
    for num in range(1, 101):
        # Print FizzBizz if no remainder after dividing by 5 and 8
        if (num % 5) == 0 and (num % 8) == 0:
            print("FizzBizz")
        # Print Fizz else if num % 5 is 0
        elif (num % 5) == 0:
            print("Fizz")
        # Print Bizz else if num % 8 is 0
        elif num % 8 == 0:
            print("Bizz")
        # Print num in any other cases
        else:
            print(num)

    # Update global counter
    Q2Ctr += 1



# Program 3 – Employee Information
# Author: Michelle Anderson
# Dated - Feb 26, 2024
def Q3():

    # Initialize global counter
    global Q3Ctr

    #Constants
    PASSWORD = "PASSWORD"

    # get current date
    CurrDate = datetime.datetime.now()
    CurrDateDsp = CurrDate.strftime("%d-%b-%y")


    # Check password to allow access to user or end program with -1
    while True:
        user_pasword = input("Enter password (or -1 to exit program): ")
        if user_pasword == PASSWORD:
            pass
        elif user_pasword == "-1":
            break
        else:
            print("Password Incorrect, please try again")
            continue


        # gather inputs
        while True:
            EmpNum = input("Enter the employee number (999-999-999)").replace("-", '')


            if EmpNum == "":
                print("Data Entry Error - Employee number cannot be blank.")


            elif len(EmpNum) != 9:
                print("Data Entry Error - Employee number must be 9 digits.")

            else:
                break


        while True:
            EmpFirstName = input("Enter the employee's first name: ").title()
            if EmpFirstName == "":
                print("Data Entry Error - Customer first name cannot be blank.")
            else:
                break

        while True:
            EmpLastName = input("Enter the employee's last name: ").title()
            if EmpLastName == "":
                print("Data Entry Error - Customer last name cannot be blank.")
            else:
                break

        while True:
            try:
                EmpStartDate = input("Enter the employee's Start date (YYYY-MM-DD): ")
                EmpStartDate = datetime.datetime.strptime(EmpStartDate, "%Y-%m-%d")
            except:
                print("Data Entry Error - start date is not in a valid format.")
            else:
                break

        while True:
            try:
                EmpBirthDate = input("Enter the employee's Birthday (YYYY-MM-DD): ")
                EmpBirthDate = datetime.datetime.strptime(EmpBirthDate, "%Y-%m-%d")
            except:
                print("Data Entry Error - start date is not in a valid format.")
            else:
                break


        # Calculuations
        YearsPunched = (CurrDate.year - EmpStartDate.year)


        next_birthday = datetime.datetime(CurrDate.year, EmpBirthDate.month, EmpBirthDate.day)
        if CurrDate > next_birthday:
            next_birthday = datetime.datetime(CurrDate.year + 1, EmpBirthDate.month, EmpBirthDate.day)

        # Calculate the number of days until the next birthday
        DaysToBirthday = (next_birthday - CurrDate).days

        RetirementDate = EmpBirthDate + datetime.timedelta(days=23725)

        EmpStartDateDsp = EmpStartDate.strftime("%d-%b-%y")
        EmpBirthDateDsp = EmpBirthDate.strftime("%b-%d-%Y")
        RetirementDateDsp = RetirementDate.strftime("%b-%d-%Y")


        # outputs
        print("---------------------------------------------------------")
        print()
        print("Employees First Name: ", EmpFirstName)
        print()
        print("Employees Last Name: ", EmpLastName)
        print()
        print("Todays Date: ", CurrDateDsp)
        print()
        print(f"Start Date: {EmpStartDateDsp}")
        print()
        print("Employee's Birthday: ", EmpBirthDateDsp)
        print()
        print("-----------------------------------------------------------")
        print("Days until employees birthday: ", DaysToBirthday)
        print()
        print("Number of years employee has worked with Company: ", YearsPunched)
        print()

        print("Employee's retirement date: ", RetirementDateDsp)
        print()
        EmpID = EmpFirstName[0] + EmpLastName[0] + "-" + EmpNum[3:6]
        print("Employee's ID number: ", EmpID)
        print()
        EmpUsername = EmpFirstName + EmpLastName[0] + EmpNum[0:3]
        print("Employee's username: ", EmpUsername)
        print()



        Q3Ctr += 1



# Program #4 - Equipment maintenance scheduler for the XYZ company
# Author: Stephen Crocker
# Dated - Feb 26, 2024

def Q4():

    # Initialize global counter
    global Q4Ctr

    # Set Constants
    EQUIPTMENT_LIFE = 180
    SALVAGE_RATE = 0.1


    # Get user inputs

    # Outer loop to conintue program until "End" prompt is entered
    while True:
        equipment_name = input("Enter the name of equipment (or end to terminate program): ").title()
        if equipment_name == "End":
             break

        # Inner loops to perform input validation

        while True:
            equipment_cost = input("Enter the cost of the equipment: ")
            stripped_equipment_cost = equipment_cost.replace(".", '')
            if stripped_equipment_cost.isdigit():
                equipment_cost = float(equipment_cost)
                break
            else:
                print("Incorrect equipment cost. Try again.")


        while True:
            purchase_date = input("Enter the invoice date (YYYY-MM-DD): \n")
            try:
                purchase_date_string = datetime.datetime.strptime(purchase_date, "%Y-%m-%d")
            except ValueError:
                print("Incorrect date. Try again.")
                continue
            break


        # Date calculations
        days_since_purchase = (CUR_DATE - purchase_date_string).days

        basic_cleaning_date = purchase_date_string + datetime.timedelta(days=10)
        basic_cleaning_date_str = basic_cleaning_date.strftime("%Y-%m-%d")
        tube_cleaning_date = purchase_date_string + datetime.timedelta(weeks=3)
        tube_cleaning_date_str = tube_cleaning_date.strftime("%Y-%m-%d")
        major_inspection_date = purchase_date_string + datetime.timedelta(weeks=26)
        major_inspection_date_str = major_inspection_date.strftime("%Y-%m-%d")

        # Cost calculations
        salvage_value = equipment_cost * SALVAGE_RATE
        monthly_ammortization = (equipment_cost - salvage_value) / EQUIPTMENT_LIFE


        #Display
        print("\n")
        print(f"{'Equipment Name:':<25s} {equipment_name}")
        print(f"{'Equipment Cost:':<25s} ${equipment_cost:,.2f}")
        print(f"{'Purchase Date:':<25s} {purchase_date}")
        print(f"{'Days since purchase:':<25s} {days_since_purchase}\n")

        print(f"{'The next basic cleaning date is on:':<35s} {basic_cleaning_date_str}")
        print(f"{'The next tube cleaning date is on:':<35s} {tube_cleaning_date_str}")
        print(f"{'The major inspection date is on:':<35s} {major_inspection_date_str}\n")

        print(f"{'The salvage value (10% of purchase) is:':<40s}${salvage_value:.2f}")
        print(f"{'The Monthly amortization is:':<40s}${monthly_ammortization:,.2f} per month for 180 months")

        # Update global counter
        Q4Ctr += 1

        while True:
            Continue = input("Do you want to Process Another Sale (Y / N)?: ").upper()
            if Continue != "Y" and Continue != "N":
                print("Enter Y to Process Another Sale, or N to exit - Please re-enter.")
            elif Continue == "N":
                exit()




# Initialize global counter
def Q5():
    global Q5Ctr, countdown_time, falling_objects, wave_timer, SPAWN_RATE, total_objects_spawned, score, wave_number

    # Program 5 - SpaceShip Destroyer
    import pygame
    import time
    import random

    # Constants

    # Screen bounds
    WIDTH, HEIGHT = 600, 600
    FPS = 60
    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)

    # Time
    INITIAL_COUNTDOWN_TIME = 60
    WAVE_TIME = 10

    # Spawning
    SPAWN_RATE = 2
    STARTING_ROUND = 1

    # Initialize Pygame
    pygame.init()

    # Set up game window
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("ClickThePy")
    clock = pygame.time.Clock()

    # Set game variables
    start_time = time.time()
    countdown_time = INITIAL_COUNTDOWN_TIME
    font = pygame.font.Font(None, 36)
    image = pygame.image.load("EnemySpaceShip.png")
    image = pygame.transform.scale(image, (50, 50))
    falling_objects = []
    score = 0
    total_objects_spawned = 0
    wave_number = STARTING_ROUND
    wave_timer = WAVE_TIME

    # Initialize game objects and features
    def initialize_game():
        return (
            pygame.display.set_mode((WIDTH, HEIGHT)),
            pygame.time.Clock(),
            pygame.font.Font(None, 36),
            pygame.image.load("EnemySpaceShip.png"),
            [],
            0,
            time.time(),
            STARTING_ROUND,
        )

    # Create falling object to spawn in game
    def create_falling_object():
        global total_objects_spawned
        total_objects_spawned += 1
        x = random.randint(0, WIDTH - 50)
        y = 0
        speed = random.randint(2, 5)
        return {'rect': pygame.Rect(x, y, 50, 50), 'speed': speed}

    # Update position of falling object so they appear to be falling
    def update_objects():
        global falling_objects
        for obj in falling_objects:
            obj['rect'].move_ip(0, obj['speed'])
        falling_objects = [obj for obj in falling_objects if obj['rect'].top <= HEIGHT]

    # Spawn created falling object
    def spawn_new_object():
        falling_objects.append(create_falling_object())

    # Handle changing of waves
    def change_waves():
        global wave_timer, wave_number, INITIAL_COUNTDOWN_TIME, SPAWN_RATE
        wave_number += 1
        wave_timer = WAVE_TIME
        SPAWN_RATE += 1

    # Draw text to state how many objects are spawned
    def draw_total_objects_spawned():
        total_objects_text = font.render(f"Total Objects Spawned: {total_objects_spawned}", True, WHITE)
        screen.blit(total_objects_text, (WIDTH // 2 - 150, HEIGHT - 50))

    # Draw PNG object onto game screen
    def draw_falling_objects():
        for obj in falling_objects:
            screen.blit(image, obj['rect'])

    # Draw score text to state how many objects the user has clicked on
    def draw_score():
        score_text = font.render(f"Score: {score}", True, WHITE)
        screen.blit(score_text, (10, 10))

    # Draw timer text to state how long the game has remaining
    def draw_timer():
        wave_timer_text = font.render(f"Time left: {countdown_time}", True, WHITE)
        screen.blit(wave_timer_text, (10, 50))  # Adjust the position to (10, 50) for left side

    # Draw wave timer text to state how long is left in the current wave
    def draw_wave_timer(wave_timer_seconds):
        wave_timer_text = font.render(f"Wave Time: {wave_timer_seconds:.2f}", True, WHITE)
        text_rect = wave_timer_text.get_rect()
        text_rect.topright = (WIDTH - 10, 10)
        screen.blit(wave_timer_text, text_rect)

    # Draw wave text to state the current wave
    def draw_wave_number(wave_number):
        wave_number_text = font.render(f"Wave #{wave_number}", True, WHITE)
        screen.blit(wave_number_text, (WIDTH - 425, 30))

    # Draw Spawn Rate text to state how many objects spawn per second - MAINLY USED FOR DEBUGGING PURPOSES
    def draw_SPAWN_RATE():
        SPAWN_RATE_text = font.render(f"Spawn rate is: {SPAWN_RATE}", True, WHITE)
        screen.blit(SPAWN_RATE_text, (WIDTH // 2 - 150, HEIGHT - 100))

    # Draw everything on the screen by calling all the draw functions
    def draw_screen(wave_timer_seconds, wave_number):
        screen.fill(BLACK)
        draw_falling_objects()
        draw_score()
        draw_timer()
        draw_wave_timer(wave_timer_seconds)
        draw_wave_number(wave_number)
        draw_total_objects_spawned()
        draw_SPAWN_RATE()
        pygame.display.flip()

    # Draw game over screen
    def game_over_screen():
        game_over_text = font.render("Game Over", True, WHITE)
        screen.blit(game_over_text, (WIDTH // 2 - 70, HEIGHT // 2 - 20))
        pygame.display.flip()
        time.sleep(2)

    def handle_events():
        global score, wave_number, wave_timer, countdown_time
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return 'QUIT'
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for obj in falling_objects:
                    if obj['rect'].collidepoint(event.pos):
                        falling_objects.remove(obj)
                        score += 1

        if countdown_time <= 0:
            return 'TIME_UP'

        return 'CONTINUE'

    def main():
        screen, clock, font, image, falling_objects, score, start_time, current_round_time = initialize_game()
        global countdown_time, wave_timer, SPAWN_RATE

        while True:
            event_status = handle_events()
            if event_status != 'CONTINUE':
                pygame.display.quit()
                pygame.quit()
                return event_status

            update_objects()

            elapsed_time_seconds = time.time() - start_time
            dt = clock.tick(FPS) / 1000.0

            countdown_time = max(0, INITIAL_COUNTDOWN_TIME - int(elapsed_time_seconds))
            wave_timer = max(0, wave_timer - dt)

            if wave_timer <= 0:
                change_waves()

            if random.random() < SPAWN_RATE * dt:
                spawn_new_object()

            draw_screen(wave_timer, wave_number)
            pygame.display.flip()

    main()

    # Update Global Counter
    Q5Ctr += 1



# Question 6 - Main Menu
while True:
    print()
    print("Michelle and Stephen's Midterm Sprint - Main Menu")
    print(f"Date: {CUR_DATE}")
    print(f"Session totals:  Employee Travel Claim: {Q1Ctr} FizzBizz: {Q2Ctr} Cool stuff With Strings and Dates: {Q3Ctr} XYZ Maintenance Scheduler: {Q4Ctr}  Something Old Something New: {Q5Ctr}")
    print()
    print("1. NL Chocolate Company Employee Travel Claim.")
    print("2. FizzBizz Problem.")
    print("3. Cool stuff with Strings and dates.")
    print("4. XYZ Maintenance.")
    print("5. Something Old Something New.")
    print("6. Quit")
    print()

    while True:
        try:
            Choice = input("Enter choice (1 - 6): ")
            Choice = int(Choice)
        except:
            print("Data Entry Error - must be a valid number between 1 and 6.")
        else:
            if Choice < 1 or Choice > 6:
                print("Data Entry Error - must be a valid number between 1 and 6.")
            else:
                break

    if Choice == 1:
        Q1()
    elif Choice == 2:
        Q2()
    elif Choice == 3:
        Q3()
    elif Choice == 4:
        Q4()
    elif Choice == 5:
        game_status = Q5()
        if game_status == 'QUIT':
            break
    else:
        break



print()
print("Thanks for using Michelle and Stephen's Midterm Menu!")